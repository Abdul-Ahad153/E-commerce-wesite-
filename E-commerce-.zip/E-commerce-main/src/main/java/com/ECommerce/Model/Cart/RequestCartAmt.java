package com.ECommerce.Model.Cart;

import lombok.Data;

@Data
public class RequestCartAmt {
    double amt;
    String username;
}
