package com.ECommerce.Model.Product;

import lombok.Data;

public @Data class RequestShowByid {
    String pid;
}
