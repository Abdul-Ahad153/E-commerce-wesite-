package com.ECommerce.Model.Order;

import lombok.Data;

@Data
public class OrderAddress {
    String address;
    String username;
}
