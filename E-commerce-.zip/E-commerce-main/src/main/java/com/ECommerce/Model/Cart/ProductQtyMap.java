package com.ECommerce.Model.Cart;

import com.ECommerce.Model.Product.Product;
import lombok.Data;

public @Data class ProductQtyMap {
    int qty;
    Product p1;
}
