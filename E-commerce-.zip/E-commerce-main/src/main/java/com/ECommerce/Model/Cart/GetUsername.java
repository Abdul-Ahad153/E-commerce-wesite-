package com.ECommerce.Model.Cart;

import lombok.Data;

public @Data class GetUsername {

    String username;
}
