package com.ECommerce.Model.User;

import lombok.Data;

public @Data class SignInResponse {
    private String userName;

    private String message;
}
